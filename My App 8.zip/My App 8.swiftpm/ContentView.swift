import SwiftUI



struct Advertisement: Identifiable {
    let id = UUID()
    let product: String
    let mediaType: String
    let tactic: String
    let healthImpact: Int 
    let revenuePotential: Int
}

struct EconomyEvent {
    let title: String
    let description: String
    let costModifier: Int
    let healthModifier: Int
}

// MARK: - Game Engine

class AdGameEngine: ObservableObject {
    @Published var budget: Int = 1500
    @Published var publicHealthScore: Int = 65
    @Published var currentDay: Int = 1
    @Published var feedbackMessage: String = "Welcome to MediaMunch: Extreme Sabotage. Balance corporate greed across a grueling 30-day corporate sprint. Watch for AI rivals, compounding public rage, and changing tax brackets!"
    @Published var activeEventMessage: String = "Market Status: Stable"
    @Published var competitorActionMessage: String = "AI Competitor: Currently planning strategy..."
    @Published var isGameOver: Bool = false
    @Published var gameOverReason: String = ""
    
    // Tracking historical decisions for brutal difficulty scaling
    private var consecutiveJunkCampaigns: Int = 0
    private var cleanCampaignStreak: Int = 0
    private var activeEvent: EconomyEvent? = nil
    
    let availableAds = [
        Advertisement(product:" 🦖 Sugar Dino Flakes", mediaType: "Saturday Morning Cartoons", tactic: "Aggressive toy marketing", healthImpact: -22, revenuePotential: 450),
        Advertisement(product: "🥤 Neon Spark Energy", mediaType: "Social Media Influencers", tactic: "Hidden formulas & trend baiting", healthImpact: -18, revenuePotential: 380),
        Advertisement(product: "🥦 Super Sprouts", mediaType: "Educational Games", tactic: "Low engagement reward quiz", healthImpact: 8, revenuePotential: 75),
        Advertisement(product: "🍔 Mega Crunch Burger", mediaType: "Late Night Sports Streams", tactic: "ASMR audio & extreme closeups", healthImpact: -19, revenuePotential: 510),
        Advertisement(product: "🍎 Crunchy Orchard Crisps", mediaType: "Parenting Blogs", tactic: "Premium pricing organic focus", healthImpact: 10, revenuePotential: 120),
        Advertisement(product: "🥛 Synth-Choc Shake", mediaType: "Metaverse Hangouts", tactic: "Virtual reality product placement", healthImpact: -20, revenuePotential: 410),
        Advertisement(product: "🌿 Ancient Grains Loaf", mediaType: "Health & Fitness Podcasts", tactic: "Boring but highly factual breakdowns", healthImpact: 14, revenuePotential: 110)
    ]
    
    let dailyEvents = [
        EconomyEvent(title: "🚨 Federal Health Audit", description: "All aggressive campaigns face strict scrutiny! (Negative health impacts doubled today)", costModifier: 0, healthModifier: -3),
        EconomyEvent(title: "📈 Hyper-Inflation Spike", description: "Production overhead hits the roof. (+ $200 campaign deployment costs)", costModifier: 200, healthModifier: 0),
        EconomyEvent(title: "📉 Ad Blocker Surge", description: "Viral digital reach hits an all-time low. (- $150 potential revenue)", costModifier: 0, healthModifier: 0),
        EconomyEvent(title: "🥗 Organic Wellness Trend", description: "Healthy campaigns receive boosted public engagement today!", costModifier: -75, healthModifier: 6),
        EconomyEvent(title: "📺 Viral Meme Backlash", description: "An old ad went viral for the wrong reasons. (- $250 PR damage penalty)", costModifier: 250, healthModifier: -6),
        EconomyEvent(title: "🏛️ Junk Food Super-Tax", description: "The Senate passed an emergency bill. All junk food ad revenue slashed by 30% today.", costModifier: 0, healthModifier: 0)
    ]
    
    func triggerDailyUpdates() {
        guard currentDay <= 30 else { return }
        
        // 1. Roll Random Market Shocks
        if let randomEvent = dailyEvents.randomElement() {
            activeEvent = randomEvent
            activeEventMessage = "⚠️ \(randomEvent.title): \(randomEvent.description)"
            publicHealthScore += randomEvent.healthModifier
            budget -= randomEvent.costModifier
        } else {
            activeEvent = nil
            activeEventMessage = "Market Status: Stable"
        }
        
        // 2. Run Adversarial AI Action
        runAICompetitor()
        
        // 3. Apply Brutal Scaling Operational Upkeep Tax
        let operationalCost = 120 + (currentDay * 25)
        budget -= operationalCost
        feedbackMessage += " [Morning Overhead: -$\(operationalCost)]"
        
        checkGameStatus()
    }
    
    func runAICompetitor() {
        if publicHealthScore > 50 {
            let budgetTheft = Int.random(in: 80...180)
            budget -= budgetTheft
            competitorActionMessage = "🤖 AI Rival launched 'MegaFat MegaShake'. They stole $\(budgetTheft) of your market share!"
        } else {
            let healthDrain = Int.random(in: 4...10)
            publicHealthScore -= healthDrain
            competitorActionMessage = "🤖 AI Rival ran a 'Clean Green' greenwashing campaign. Your Public Health dropped by \(healthDrain) points due to comparison!"
        }
    }
    
    func runCampaign(_ ad: Advertisement) {
        guard !isGameOver else { return }
        
        var finalCost = 250
        var finalRevenue = ad.revenuePotential
        var finalHealthImpact = ad.healthImpact
        
        if let event = activeEvent {
            if event.title == "📈 Hyper-Inflation Spike" { finalCost += 200 }
            if event.title == "📉 Ad Blocker Surge" { finalRevenue -= 150 }
            if event.title == "🚨 Federal Health Audit" && ad.healthImpact < 0 { finalHealthImpact *= 2 }
            if event.title == "🏛️ Junk Food Super-Tax" && ad.healthImpact < 0 { finalRevenue = Int(Double(finalRevenue) * 0.7) }
        }
        
        if budget < finalCost {
            feedbackMessage = "Day \(currentDay): Bank account locked! Not enough capital to deploy this strategy."
            return
        }
        
        if ad.healthImpact < 0 {
            consecutiveJunkCampaigns += 1
            cleanCampaignStreak = 0
            if consecutiveJunkCampaigns >= 2 {
                finalHealthImpact -= (consecutiveJunkCampaigns * 6) 
            }
        } else {
            consecutiveJunkCampaigns = 0 
            cleanCampaignStreak += 1
            if cleanCampaignStreak > 3 {
                finalRevenue = Int(Double(finalRevenue) * 0.75)
            }
        }
        
        budget -= finalCost
        budget += finalRevenue
        publicHealthScore += finalHealthImpact
        publicHealthScore = max(0, min(100, publicHealthScore))
        
        if ad.healthImpact < 0 {
            feedbackMessage = "Day \(currentDay): Launched \(ad.product). Revenue gained, but aggressive targeting penalised community health by \(abs(finalHealthImpact)) points."
            if consecutiveJunkCampaigns >= 2 {
                feedbackMessage += " (⚠️ Public health backlash is compounding rapidly!)"
            }
        } else {
            feedbackMessage = "Day \(currentDay): Ethical push with \(ad.product) gained advocacy approval (Health +\(finalHealthImpact))."
            if cleanCampaignStreak > 3 {
                feedbackMessage += " (📉 Market saturation: Clean ads generating 25% lower returns due to public fatigue)."
            }
        }
        
        currentDay += 1
        triggerDailyUpdates()
    }
    
    func checkGameStatus() {
        if publicHealthScore <= 0 {
            isGameOver = true
            gameOverReason = "CRITICAL INSOLVENCY: Public Health reached 0. Federal anti-monopoly commissions seized your digital assets and closed your agency."
        } else if budget <= 0 {
            isGameOver = true
            gameOverReason = "LIQUIDATION: Cash balance hit $0. Venture capitalist backers staged a corporate takeover and locked your access keys."
        } else if currentDay > 30 {
            isGameOver = true
            if publicHealthScore >= 80 && budget >= 5000 {
                gameOverReason = "ELITE MONOPOLIST VICTORY: You navigated all 30 days! You completely outmanoeuvred the AI firm, finishing with an elite corporate balance ($5,000+) and flawless ethical ratings (80+)."
            } else {
                gameOverReason = "MEDIOCRE EXIT: You survived 30 days, but your metrics ($5,000 budget and 80+ Health requirement) fell short. The board voted to replace you with an AI algorithm."
            }
        }
    }
    
    func resetGame() {
        budget = 1500
        publicHealthScore = 65
        currentDay = 1
        consecutiveJunkCampaigns = 0
        cleanCampaignStreak = 0
        activeEvent = nil
        feedbackMessage = "Simulation reset to Day 1. AI models recalibrated. Good luck."
        activeEventMessage = "Market Status: Stable"
        competitorActionMessage = "AI Competitor: Currently planning strategy..."
        isGameOver = false
        gameOverReason = ""
    }
}

// MARK: - UI Views

struct ContentView: View {
    @StateObject private var engine = AdGameEngine()
    
    struct MetricCard: View {
        let title: String
        let value: String
        let icon: String
        let color: Color
        
        var body: some View {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundColor(color)
                Text(value)
                    .font(.headline)
                    .bold()
                Text(title)
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .textCase(.uppercase)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(Color(.secondarySystemGroupedBackground))
            .cornerRadius(12)
        }
    }
    
    var body: some View {
        ZStack {
            Color(.systemGroupedBackground)
                .ignoresSafeArea()
            
            VStack(spacing: 14) {
                VStack(spacing: 4) {
                    Text("MediaMunch: Hyper-Corporate")
                        .font(.system(.title2, design: .rounded))
                        .bold()
                    Text("30-Day Adversarial Sabotage Engine")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .padding(.top, 10)
                HStack(spacing: 12) {
                    MetricCard(title: "Capital", value: "$\(engine.budget)", icon: "dollarsign.circle.fill", color: engine.budget < 500 ? .red : .green)
                    
                    MetricCard(title: "Public Health", value: "\(engine.publicHealthScore)/100", icon: "heart.text.square.fill", color: engine.publicHealthScore < 45 ? .red : .blue)
                    
                    MetricCard(title: "Timeline", value: "Day \(engine.currentDay)/30", icon: "clock.fill", color: .purple)
                }
                .padding(.horizontal)
                VStack(alignment: .leading, spacing: 4) {
                    Text(engine.competitorActionMessage)
                        .font(.caption)
                        .bold()
                        .foregroundColor(.red)
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.red.opacity(0.1))
                .cornerRadius(8)
                .padding(.horizontal)
                VStack(alignment: .leading, spacing: 4) {
                    Text(engine.activeEventMessage)
                        .font(.caption)
                        .bold()
                        .foregroundColor(.orange)
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.orange.opacity(0.12))
                .cornerRadius(8)
                .padding(.horizontal)
                VStack(alignment: .leading, spacing: 6) {
                    Text("Live Network Ticker Feed")
                        .font(.caption2)
                        .bold()
                        .foregroundColor(.secondary)
                        .textCase(.uppercase)
                    Text(engine.feedbackMessage)
                        .font(.caption)
                        .italic()
                        .foregroundColor(.primary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding()
                .background(Color(.secondarySystemGroupedBackground))
                .cornerRadius(12)
                .padding(.horizontal)
                Text("Select Strategic Deployment ($250+ base cost)")
                    .font(.subheadline)
                    .bold()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)
                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(engine.availableAds) { ad in
                            Button(action: {
                                engine.runCampaign(ad)
                            }) {
                                AppAdRow(ad: ad)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .blur(radius: engine.isGameOver ? 6 : 0)
            .disabled(engine.isGameOver)
            if engine.isGameOver {
                Color.black.opacity(0.55)
                    .ignoresSafeArea()
                VStack(spacing: 22) {
                    Text("Simulation Terminated")
                        .font(.title2)
                        .bold()
                    Text(engine.gameOverReason)
                        .font(.body)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                        .padding(.horizontal)
                    Button(action: {
                        engine.resetGame()
                    }) {
                        Text("Initiate Hard Reset")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.red)
                            .cornerRadius(12)
                    }
                    .padding(.horizontal, 30)
                }
                .padding(24)
                .background(Color(.systemBackground))
                .cornerRadius(20)
                .shadow(radius: 12)
                .padding(24)
            }
        }
    }
}
// MARK: - Row Helper Component
struct AppAdRow: View {
    let ad: Advertisement
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(ad.product)
                    .font(.subheadline)
                    .bold()
                Text("(ad.mediaType)\n↳ Strategy: (ad.tactic)")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 4) {
                Text("+(ad.revenuePotential) 💰")
                    .font(.caption)
                    .bold()
                    .foregroundColor(.green)
                Text("(ad.healthImpact) 🩺")
                    .font(.caption2)
                    .bold()
                    .foregroundColor(ad.healthImpact < 0 ? .red : .green)
            }
        }
        .padding()
        .background(Color(.secondarySystemGroupedBackground))
        .cornerRadius(12)
    }
}
